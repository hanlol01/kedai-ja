'use client';

import SmartChatButton from './SmartChatButton';

export default function FloatingChatButton() {
  return <SmartChatButton />;
} 