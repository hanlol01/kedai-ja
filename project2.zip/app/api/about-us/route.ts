import { NextRequest, NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import AboutUs from '@/models/AboutUs';
import { getSession } from '@/lib/auth';

// Cache data untuk mengurangi waktu loading
let cachedAboutUs: any = null;
let cacheTime: number = 0;
const CACHE_DURATION = 60 * 60 * 1000; // 1 jam dalam milidetik

export async function GET() {
  try {
    // Gunakan data cache jika masih valid
    const now = Date.now();
    if (cachedAboutUs && (now - cacheTime < CACHE_DURATION)) {
      return NextResponse.json({ 
        success: true, 
        aboutUs: cachedAboutUs,
        fromCache: true
      });
    }

    // Set timeout untuk database query (dipersingkat agar respons lebih cepat)
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Database query timeout')), 5000); // 2 detik timeout
    });

    // Connect ke database dengan timeout
    await Promise.race([connectDB(), timeoutPromise]);
    
    // Query database dengan timeout
    const aboutUsPromise = AboutUs.findOne({});
    let aboutUs = await Promise.race([aboutUsPromise, timeoutPromise]);
    
    if (!aboutUs) {
      const defaultAboutUs = {
        title: 'About Us',
        subtitle: 'Welcome to Kedai J.A',
        description: 'Kedai J.A adalah destinasi kuliner yang menghadirkan cita rasa autentik Indonesia dengan sentuhan modern. Kami berkomitmen untuk menyajikan hidangan berkualitas tinggi dengan bahan-bahan segar pilihan.',
        secondDescription: 'Dengan pengalaman bertahun-tahun di industri kuliner, kami terus berinovasi untuk memberikan pengalaman dining yang tak terlupakan. Setiap hidangan dibuat dengan penuh cinta dan keahlian oleh chef berpengalaman kami.',
        companyDescription: 'Kedai J.A adalah destinasi kuliner yang menghadirkan cita rasa autentik Indonesia dengan sentuhan modern. Didirikan dengan visi untuk melestarikan warisan kuliner nusantara, kami berkomitmen menyajikan hidangan berkualitas tinggi menggunakan bahan-bahan segar pilihan dan resep turun-temurun yang telah diwariskan dari generasi ke generasi.',
        yearsOfExperience: 7,
        masterChefs: 25,
        images: {
          image1: '',
          image2: '',
          image3: '',
          image4: '',
          lingkunganKedai: [],
          spotTempatDuduk: []
        }
      };
      
      aboutUs = new AboutUs(defaultAboutUs);
      await Promise.race([aboutUs.save(), timeoutPromise]);
    }
    
    // Update cache
    cachedAboutUs = aboutUs;
    cacheTime = now;
    
    return NextResponse.json({ 
      success: true, 
      aboutUs 
    });
  } catch (error: any) {
    if (error && error.message === 'Database query timeout') {
      console.warn('About Us query timed out, serving fallback/cache');
    } else {
      console.error('Error fetching about us:', error);
    }
    
    // Gunakan cache jika ada error tapi cache tersedia
    if (cachedAboutUs) {
      return NextResponse.json({ 
        success: true, 
        aboutUs: cachedAboutUs,
        fromCache: true,
        note: 'Served from cache due to error'
      });
    }
    
    // Fallback data jika tidak ada cache
    const fallbackData = {
      title: 'About Us',
      subtitle: 'Welcome to Kedai J.A',
      description: 'Kedai J.A adalah destinasi kuliner yang menghadirkan cita rasa autentik Indonesia dengan sentuhan modern.',
      secondDescription: 'Dengan pengalaman bertahun-tahun di industri kuliner, kami terus berinovasi untuk memberikan pengalaman dining yang tak terlupakan.',
      companyDescription: 'Kedai J.A adalah destinasi kuliner yang menghadirkan cita rasa autentik Indonesia dengan sentuhan modern.',
      yearsOfExperience: 7,
      masterChefs: 25,
      images: {
        image1: '',
        image2: '',
        image3: '',
        image4: '',
        lingkunganKedai: [],
        spotTempatDuduk: []
      }
    };
    
    return NextResponse.json(
      { 
        success: true, 
        aboutUs: fallbackData,
        fromFallback: true
      },
      { status: 200 } // Tetap kembalikan 200 untuk menghindari error di client
    );
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getSession(request);
    if (!session) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }

    // Batasi waktu koneksi DB untuk mencegah request menggantung, waktu ditambah untuk gambar yang lebih besar
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Database write timeout')), 20000); // 20 detik timeout
    });

    await Promise.race([connectDB(), timeoutPromise]);
    
    const updateData = await request.json();

    // Gunakan findOneAndUpdate agar lebih cepat dan atomic
    const updatePromise = AboutUs.findOneAndUpdate(
      {},
      { $set: updateData },
      { new: true, upsert: true, setDefaultsOnInsert: true, maxTimeMS: 20000 }
    );

    const aboutUs = await Promise.race([updatePromise, timeoutPromise]);
    
    // Invalidate & refresh cache setelah update
    cachedAboutUs = aboutUs;
    cacheTime = Date.now();

    return NextResponse.json({ 
      message: 'About us updated successfully',
      aboutUs 
    });
  } catch (error: any) {
    if (error && (error.message === 'Database write timeout' || error.name === 'MongoNetworkTimeoutError')) {
      console.warn('Update about us timed out');
      return NextResponse.json(
        { error: 'Koneksi database lambat atau tidak tersedia. Coba lagi beberapa saat.' },
        { status: 503 }
      );
    }
    console.error('Update about us error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}